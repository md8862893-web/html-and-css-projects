# Chayapoth Studio API

Minimal backend for the contact form: validation, rate limiting, and a clean MVC-style structure.

## Structure (clean architecture)

```
server/
├── src/
│   ├── config/               # Config (env, rate limit, API path)
│   ├── controllers/         # contact.controller.js
│   ├── middleware/          # errorHandler, notFound
│   ├── routes/              # contact.routes.js
│   ├── validators/          # contact.validator.js
│   └── index.js             # App entry
├── .env.example
├── package.json
└── README.md
```

## Security

- **Helmet** — security headers.
- **CORS** — only `CORS_ORIGIN` is allowed (set in `.env`).
- **Rate limit** — 10 requests per 15 minutes per IP for `/api/contact`.
- **Body limit** — JSON body limited to 10kb.
- **Validation** — all inputs validated and sanitized (allowlist for enums, length limits, email format).
- **Errors** — no stack traces or internal details in production responses.

## Setup

```bash
cd server
cp .env.example .env
# Edit .env: set CORS_ORIGIN to your frontend origin (e.g. http://localhost:5500)
npm install
npm run dev
```

## Contact form (frontend)

On the contact page, set the form’s `data-api` to the API URL so the client sends POST to the backend:

```html
<form class="contact-form" data-api="http://localhost:3000/api/contact" ...>
```

If the site is served from the same origin as the API, you can use a relative URL:

```html
<form class="contact-form" data-api="/api/contact" ...>
```

## API

### POST /api/contact

**Body (JSON):** `name`, `email`, `projectType`, `message` (required); `company`, `budget`, `heardFrom` (optional).

**Validation:** Name/email/message length and format; `projectType` must be one of: `website`, `webapp`, `app`, `software`, `rom`, `video`, `other`.

**Responses:**

- `201` — success.
- `400` — validation failed (body includes `errors` array).
- `429` — too many requests (rate limit).
- `500` — server error (generic message in production).

## Production

- Set `NODE_ENV=production`.
- Set `CORS_ORIGIN` to your real frontend origin.
- Add real contact handling (e.g. send email, save to DB) in `controllers/contactController.js`.
