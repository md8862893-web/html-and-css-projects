/**
 * Application config. Prefer env vars in production.
 * CORS_ORIGIN must be a single origin in production (no wildcards).
 */
const DEFAULT_PORT = 3000;
const DEFAULT_CORS_ORIGIN = "http://localhost:5500";
const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000;
const RATE_LIMIT_MAX_REQUESTS = 10;

const config = {
  port: Number(process.env.PORT) || DEFAULT_PORT,
  corsOrigin: process.env.CORS_ORIGIN || DEFAULT_CORS_ORIGIN,
  nodeEnv: process.env.NODE_ENV || "development",
  api: {
    contactPath: "/api/contact",
    rateLimit: {
      windowMs: RATE_LIMIT_WINDOW_MS,
      max: RATE_LIMIT_MAX_REQUESTS,
    },
  },
};

module.exports = { config };
