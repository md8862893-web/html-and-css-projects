const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { config } = require("./config");
const contactRoutes = require("./routes/contact.routes");
const { errorHandler } = require("./middleware/errorHandler");
const { notFound } = require("./middleware/notFound");

const app = express();

app.use(helmet());
app.use(
  cors({
    origin: config.corsOrigin,
    methods: ["GET", "POST"],
    allowedHeaders: ["Content-Type"],
  })
);

app.use(express.json({ limit: "10kb" }));

const contactLimiter = rateLimit({
  windowMs: config.api.rateLimit.windowMs,
  max: config.api.rateLimit.max,
  message: { success: false, message: "Too many requests. Try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

app.use(config.api.contactPath, contactLimiter);
app.use(config.api.contactPath, contactRoutes);

app.use(notFound);
app.use(errorHandler);

app.listen(config.port, () => {
  console.info(`Server listening on port ${config.port} (${config.nodeEnv})`);
});
