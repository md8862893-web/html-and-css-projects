/**
 * Contact form validation and sanitization.
 * Returns { valid: false, errors: [...] } or { valid: true, data: {...} }.
 */

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ALLOWED_PROJECT_TYPES = new Set([
  "website", "webapp", "app", "software", "rom", "video", "other",
]);
const ALLOWED_BUDGETS = new Set([
  "", "small", "medium", "large", "unknown",
]);

const LIMITS = {
  name: { max: 120 },
  email: { max: 254 },
  company: { max: 200 },
  message: { min: 10, max: 5000 },
  heardFrom: { max: 200 },
};

function trim(str) {
  return typeof str === "string" ? str.trim() : "";
}

function sanitizeString(str, maxLen) {
  const s = trim(str);
  if (maxLen && s.length > maxLen) return s.slice(0, maxLen);
  return s;
}

function validateContact(body) {
  const errors = [];
  const raw = {
    name: body.name,
    email: body.email,
    company: body.company,
    projectType: body.projectType,
    budget: body.budget,
    heardFrom: body.heardFrom,
    message: body.message,
  };

  const name = sanitizeString(raw.name, LIMITS.name.max);
  if (!name) {
    errors.push({ field: "name", message: "Name is required." });
  }

  const email = sanitizeString(raw.email, LIMITS.email.max);
  if (!email) {
    errors.push({ field: "email", message: "Email is required." });
  } else if (!EMAIL_REGEX.test(email)) {
    errors.push({ field: "email", message: "Invalid email format." });
  }

  const projectType = trim(raw.projectType);
  if (!projectType) {
    errors.push({ field: "projectType", message: "Project type is required." });
  } else if (!ALLOWED_PROJECT_TYPES.has(projectType)) {
    errors.push({ field: "projectType", message: "Invalid project type." });
  }

  const budget = trim(raw.budget || "");
  if (budget && !ALLOWED_BUDGETS.has(budget)) {
    errors.push({ field: "budget", message: "Invalid budget value." });
  }

  const message = sanitizeString(raw.message, LIMITS.message.max);
  if (!message) {
    errors.push({ field: "message", message: "Message is required." });
  } else if (message.length < LIMITS.message.min) {
    errors.push({
      field: "message",
      message: `Message must be at least ${LIMITS.message.min} characters.`,
    });
  }

  const company = sanitizeString(raw.company, LIMITS.company.max);
  const heardFrom = sanitizeString(raw.heardFrom, LIMITS.heardFrom.max);

  if (errors.length > 0) {
    return { valid: false, errors };
  }

  return {
    valid: true,
    data: {
      name,
      email,
      company: company || undefined,
      projectType,
      budget: budget || undefined,
      heardFrom: heardFrom || undefined,
      message,
    },
  };
}

module.exports = { validateContact, LIMITS };
