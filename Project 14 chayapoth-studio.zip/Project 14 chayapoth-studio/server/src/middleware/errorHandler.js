/**
 * Central error handler. Never leak stack or internal details in production.
 */
function errorHandler(err, req, res, next) {
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ success: false, message: "Invalid JSON body." });
  }

  const status = err.statusCode || err.status || 500;
  const isProd = process.env.NODE_ENV === "production";

  if (!isProd) {
    console.error(err);
  }

  res.status(status).json({
    success: false,
    message: isProd ? "Something went wrong. Please try again later." : err.message,
    ...(isProd ? {} : { stack: err.stack }),
  });
}

module.exports = { errorHandler };
