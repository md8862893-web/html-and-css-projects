/**
 * Contact controller: handles POST /api/contact.
 * Validates input, then processes (e.g. send email, save to DB).
 * For now we only validate and return success; no persistence.
 * Do not log request body or PII in production.
 */

const { validateContact } = require("../validators/contact.validator");

function postContact(req, res, next) {
  try {
    const result = validateContact(req.body || {});

    if (!result.valid) {
      return res.status(400).json({
        success: false,
        message: "Validation failed.",
        errors: result.errors,
      });
    }

    const { data } = result;
    if (process.env.NODE_ENV !== "production") {
      console.info("[Contact]", {
        name: data.name,
        email: data.email,
        projectType: data.projectType,
      });
    }

    return res.status(201).json({
      success: true,
      message: "Thank you. We will get back to you soon.",
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { postContact };
