/**
 * Chayapoth Studio — client app module.
 * Validation, form handling, and shared utilities. No eval; inputs sanitized and length-limited.
 *
 * @namespace App
 * @property {Object} LIMITS - Max lengths for form/search fields (searchQuery, name, email, company, message, messageMin, heardFrom).
 * @property {function(string, number=): string} sanitize - Trims and optionally truncates a string.
 * @property {function(string): string} trim - Trims a string; returns "" for non-strings.
 * @property {function(): string} getStoredLang - Returns stored language ("en" | "bn"); safe for private browsing.
 * @property {function(string): void} setStoredLang - Persists language; only "en" and "bn" are stored.
 * @property {function(HTMLFormElement): {errors: Array<{field: string, message: string}>, data: Object|null}} validateContactForm - Client-side contact form validation.
 * @property {function(HTMLFormElement, string, string, Array=): void} showFormFeedback - Shows success or error message (and optional field errors) below submit button.
 * @property {function(HTMLFormElement): void} removeFormFeedback - Removes any existing .form-feedback node.
 * @property {function(HTMLFormElement, string): Promise<void>} submitContactForm - Validates, POSTs to apiUrl, shows success/error feedback.
 */
const App = (function () {
  "use strict";

  const LANG_KEY = "chayapoth-lang";
  const ALLOWED_LANGS = ["en", "bn"];

  const LIMITS = {
    searchQuery: 200,
    name: 120,
    email: 254,
    company: 200,
    message: 5000,
    messageMin: 10,
    heardFrom: 200,
  };

  const ALLOWED_PROJECT_TYPES = new Set([
    "website", "webapp", "app", "software", "rom", "video", "other",
  ]);

  function trim(str) {
    return typeof str === "string" ? str.trim() : "";
  }

  function sanitize(str, maxLen) {
    const s = trim(str);
    if (maxLen != null && s.length > maxLen) return s.slice(0, maxLen);
    return s;
  }

  function isValidEmail(email) {
    if (!email) return false;
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function getStoredLang() {
    try {
      const stored = localStorage.getItem(LANG_KEY);
      return ALLOWED_LANGS.includes(stored) ? stored : "en";
    } catch (_) {
      return "en";
    }
  }

  function setStoredLang(lang) {
    if (!ALLOWED_LANGS.includes(lang)) return;
    try {
      localStorage.setItem(LANG_KEY, lang);
    } catch (_) {}
  }

  function validateContactForm(form) {
    const errors = [];
    const name = sanitize((form.querySelector('[name="name"]')?.value) || "", LIMITS.name);
    const email = sanitize((form.querySelector('[name="email"]')?.value) || "", LIMITS.email);
    const projectType = trim(form.querySelector('[name="projectType"]')?.value || "");
    const message = sanitize((form.querySelector('[name="message"]')?.value) || "", LIMITS.message);

    if (!name) errors.push({ field: "name", message: "Name is required." });
    if (!email) errors.push({ field: "email", message: "Email is required." });
    else if (!isValidEmail(email)) errors.push({ field: "email", message: "Invalid email format." });
    if (!projectType) errors.push({ field: "projectType", message: "Project type is required." });
    else if (!ALLOWED_PROJECT_TYPES.has(projectType)) errors.push({ field: "projectType", message: "Invalid project type." });
    if (!message) errors.push({ field: "message", message: "Message is required." });
    else if (message.length < LIMITS.messageMin) errors.push({ field: "message", message: "Message is too short." });

    return { errors, data: errors.length === 0 ? { name, email, projectType, message } : null };
  }

  function getContactFormData(form) {
    const data = {
      name: sanitize(form.querySelector('[name="name"]')?.value || "", LIMITS.name),
      email: sanitize(form.querySelector('[name="email"]')?.value || "", LIMITS.email),
      company: sanitize(form.querySelector('[name="company"]')?.value || "", LIMITS.company),
      projectType: trim(form.querySelector('[name="projectType"]')?.value || ""),
      budget: trim(form.querySelector('[name="budget"]')?.value || ""),
      heardFrom: sanitize(form.querySelector('[name="heardFrom"]')?.value || "", LIMITS.heardFrom),
      message: sanitize(form.querySelector('[name="message"]')?.value || "", LIMITS.message),
    };
    return data;
  }

  function showFormFeedback(form, type, message, fieldErrors = []) {
    const existing = form.querySelector(".form-feedback");
    if (existing) existing.remove();

    const wrap = document.createElement("div");
    wrap.className = "form-feedback form-feedback--" + type;
    wrap.setAttribute("role", "alert");

    const p = document.createElement("p");
    p.textContent = message;
    wrap.appendChild(p);

    if (fieldErrors.length > 0) {
      const ul = document.createElement("ul");
      ul.className = "form-feedback-list";
      fieldErrors.forEach((e) => {
        const li = document.createElement("li");
        li.textContent = e.message;
        if (e.field) li.setAttribute("data-field", e.field);
        ul.appendChild(li);
      });
      wrap.appendChild(ul);
    }

    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) submitBtn.after(wrap);
  }

  function removeFormFeedback(form) {
    const existing = form.querySelector(".form-feedback");
    if (existing) existing.remove();
  }

  async function submitContactForm(form, apiUrl) {
    removeFormFeedback(form);
    const validation = validateContactForm(form);
    if (validation.errors.length > 0) {
      showFormFeedback(
        form,
        "error",
        "Please fix the errors below.",
        validation.errors
      );
      return;
    }

    const data = getContactFormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn?.textContent;
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = "Sending…";
    }

    try {
      const res = await fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json = await res.json().catch(() => ({}));

      if (!res.ok) {
        const errors = Array.isArray(json.errors) ? json.errors : [{ message: json.message || "Request failed." }];
        showFormFeedback(form, "error", json.message || "Something went wrong.", errors);
        return;
      }

      showFormFeedback(form, "success", json.message || "Thank you. We will get back to you soon.");
      form.reset();
    } catch (err) {
      showFormFeedback(form, "error", "Network error. Please check your connection and try again.");
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText || "Send message";
      }
    }
  }

  return {
    sanitize,
    trim,
    getStoredLang,
    setStoredLang,
    LIMITS,
    validateContactForm,
    showFormFeedback,
    removeFormFeedback,
    submitContactForm,
  };
})();
