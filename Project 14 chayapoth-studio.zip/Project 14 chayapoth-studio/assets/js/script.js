// ========== 1. MOBILE NAV TOGGLE ==========
const mobileMenuToggle = document.getElementById("mobileMenuToggle");
const mobileNav = document.getElementById("mobileNav");

if (mobileMenuToggle && mobileNav) {
    mobileMenuToggle.addEventListener("click", () => {
        mobileNav.classList.toggle("open");
    });
}

// Close mobile nav on link click (optional but nicer UX)
if (mobileNav) {
    mobileNav.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", () => {
            mobileNav.classList.remove("open");
        });
    });
}

// ========== 2. FOOTER YEAR ==========
const yearSpan = document.getElementById("year");
if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
}

// ========== 3. LANGUAGE TOGGLE (BASIC STUB) ==========
const langButtons = document.querySelectorAll('[data-lang]');
const textNodes = document.querySelectorAll('[data-en][data-bn]');

function setLanguage(lang) {
    // Update all elements with data-en / data-bn
    textNodes.forEach(el => {
        const en = el.getAttribute('data-en');
        const bn = el.getAttribute('data-bn');
        if (lang === 'bn' && bn) {
            el.textContent = bn;
            el.classList.add('bn-text');
        } else if (en) {
            el.textContent = en;
            el.classList.remove('bn-text');
        }
    });

    // Activate buttons
    langButtons.forEach(btn => {
        if (btn.dataset.lang === lang) {
            btn.classList.add('active');
        } else if (btn.dataset.lang) {
            btn.classList.remove('active');
        }
    });

    // Optional: save choice in localStorage
    try {
        localStorage.setItem('chayapoth-lang', lang);
    } catch (e) {
        // ignore if disabled
    }
}

// Add click listeners
langButtons.forEach(btn => {
    const lang = btn.dataset.lang;
    if (!lang) return;
    btn.addEventListener('click', () => setLanguage(lang));
});

// Load saved language
let savedLang = 'en';
try {
    const stored = localStorage.getItem('chayapoth-lang');
    if (stored === 'bn' || stored === 'en') {
        savedLang = stored;
    }
} catch (e) {
    // ignore
}
setLanguage(savedLang);

// ========== 4. PLACEHOLDERS FOR FUTURE FEATURES ==========
// Later steps e ekhane:
// - Animation showcase / motion lab er logic
// - Search overlay / page transition etc.
// add korbo.