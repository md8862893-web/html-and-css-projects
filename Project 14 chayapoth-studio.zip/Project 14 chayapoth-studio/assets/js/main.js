/**
 * Chayapoth Studio — main entry script.
 * Load after app.js on pages that use the contact form (e.g. contact.html).
 *
 * Sections:
 * 1. Mobile nav toggle
 * 2. Search icon (navigate to search page)
 * 3. Footer year
 * 4. Language toggle (EN/BN)
 * 5. Animation showcase (home)
 * 6–7. Category and role filters (projects, blog, news, downloads, videos, team)
 * 8. FAQ accordion (support)
 * 9. Auth tabs (login/signup)
 * 10. Search page filters
 * 11. Contact form
 * 12. Auth forms (demo prevent submit)
 *
 * DOM identifiers: mobileMenuToggle, mobileNav, searchToggle, year, mainContent,
 * animTarget, searchQuery, searchButton, .contact-form, .auth-form
 */

"use strict";

const SEARCH_PAGE_PATH = "search.html";
const FALLBACK_SEARCH_QUERY_MAX_LENGTH = 200;

// ========== 1. MOBILE NAV TOGGLE ==========
const mobileMenuToggle = document.getElementById("mobileMenuToggle");
const mobileNav = document.getElementById("mobileNav");

if (mobileMenuToggle && mobileNav) {
    mobileMenuToggle.addEventListener("click", () => {
        mobileNav.classList.toggle("open");
    });
}

if (mobileNav) {
    mobileNav.querySelectorAll("a").forEach((link) => {
        link.addEventListener("click", () => {
            mobileNav.classList.remove("open");
        });
    });
}

// ========== 2. SEARCH ICON -> GO TO SEARCH PAGE ==========
const searchToggleButton = document.getElementById("searchToggle");
if (searchToggleButton) {
    searchToggleButton.addEventListener("click", () => {
        window.location.href = SEARCH_PAGE_PATH;
    });
}

// ========== 3. FOOTER YEAR ==========
const yearSpan = document.getElementById("year");
if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
}

// ========== 4. LANGUAGE TOGGLE ==========
const langButtons = document.querySelectorAll("[data-lang]");
const textNodes = document.querySelectorAll("[data-en][data-bn]");

function getStoredLang() {
    if (typeof App !== "undefined" && App.getStoredLang) return App.getStoredLang();
    try {
        const s = localStorage.getItem("chayapoth-lang");
        return s === "bn" || s === "en" ? s : "en";
    } catch (_) {
        return "en";
    }
}

function setStoredLang(lang) {
    if (lang !== "en" && lang !== "bn") return;
    if (typeof App !== "undefined" && App.setStoredLang) App.setStoredLang(lang);
    else try { localStorage.setItem("chayapoth-lang", lang); } catch (_) {}
}

function setLanguage(lang) {
    const safeLang = lang === "bn" || lang === "en" ? lang : "en";

    textNodes.forEach((el) => {
        const en = el.getAttribute("data-en");
        const bn = el.getAttribute("data-bn");
        if (safeLang === "bn" && bn) {
            el.textContent = bn;
            el.classList.add("bn-text");
        } else if (en) {
            el.textContent = en;
            el.classList.remove("bn-text");
        }
    });

    langButtons.forEach((btn) => {
        if (btn.dataset.lang === safeLang) btn.classList.add("active");
        else if (btn.dataset.lang) btn.classList.remove("active");
    });

    setStoredLang(safeLang);
}

langButtons.forEach((btn) => {
    const lang = btn.dataset.lang;
    if (!lang) return;
    btn.addEventListener("click", () => setLanguage(lang));
});
setLanguage(getStoredLang());

// ========== 5. ANIMATION SHOWCASE (HOME) ==========
const animTarget = document.getElementById("animTarget");
const animButtons = document.querySelectorAll(".anim-btn");
const ANIM_CLASSES = ["anim-bounce", "anim-slide", "anim-fade-blur", "anim-rotate"];

if (animTarget && animButtons.length) {
    animButtons.forEach((btn) => {
        btn.addEventListener("click", () => {
            const animName = btn.dataset.anim;
            if (!animName) return;

            animButtons.forEach((b) => {
                b.classList.toggle("active", b === btn);
            });
            ANIM_CLASSES.forEach((cls) => animTarget.classList.remove(cls));
            void animTarget.offsetWidth;
            animTarget.classList.add(animName);
        });
    });
    animTarget.classList.add("anim-bounce");
}

// ========== 6. CATEGORY FILTER ==========
function initCategoryFilter(buttonSelector, itemSelector, hiddenClass) {
    const buttons = document.querySelectorAll(buttonSelector);
    const items = document.querySelectorAll(itemSelector);
    if (!buttons.length || !items.length) return;

    buttons.forEach((btn) => {
        btn.addEventListener("click", () => {
            const filter = (btn.dataset.filter || "all").toLowerCase();
            buttons.forEach((b) => b.classList.toggle("active", b === btn));
            items.forEach((item) => {
                const category = (item.dataset.category || "").toLowerCase();
                const show = filter === "all" || category.includes(filter);
                item.classList.toggle(hiddenClass, !show);
            });
        });
    });
}

// ========== 7. ROLE FILTER (PORTFOLIO / TEAM) ==========
function initRoleFilter(buttonSelector, itemSelector, hiddenClass) {
    const buttons = document.querySelectorAll(buttonSelector);
    const items = document.querySelectorAll(itemSelector);
    if (!buttons.length || !items.length) return;

    buttons.forEach((btn) => {
        btn.addEventListener("click", () => {
            const role = (btn.dataset.role || "all").toLowerCase();
            buttons.forEach((b) => b.classList.toggle("active", b === btn));
            items.forEach((item) => {
                const cardRole = (item.dataset.role || "").toLowerCase();
                const show = role === "all" || cardRole === role;
                item.classList.toggle(hiddenClass, !show);
            });
        });
    });
}

initCategoryFilter(".project-filter-btn", ".project-item", "project-hidden");
initRoleFilter(".team-filter-btn", ".team-card", "team-hidden");
initCategoryFilter(".blog-filter-btn", ".blog-post-item", "blog-hidden");
initCategoryFilter(".news-filter-btn", ".news-post-item", "news-hidden");
initCategoryFilter(".download-filter-btn", ".download-item", "download-hidden");
initCategoryFilter(".video-filter-btn", ".video-item", "video-hidden");

// ========== 8. FAQ ACCORDION (SUPPORT) ==========
document.querySelectorAll(".faq-question").forEach((btn) => {
    btn.addEventListener("click", () => {
        const item = btn.closest(".faq-item");
        if (item) item.classList.toggle("open");
    });
});

// ========== 9. AUTH TABS (LOGIN / SIGN UP) ==========
const authTabs = document.querySelectorAll(".auth-tab");
const loginForm = document.querySelector(".auth-form-login");
const signupForm = document.querySelector(".auth-form-signup");

if (authTabs.length && loginForm && signupForm) {
    authTabs.forEach((tab) => {
        tab.addEventListener("click", () => {
            const target = tab.dataset.authTab;
            authTabs.forEach((t) => t.classList.toggle("active", t === tab));
            if (target === "login") {
                loginForm.classList.add("active");
                signupForm.classList.remove("active");
            } else if (target === "signup") {
                signupForm.classList.add("active");
                loginForm.classList.remove("active");
            }
        });
    });
}

// ========== 10. SEARCH PAGE ==========
const searchInput = document.getElementById("searchQuery");
const searchButton = document.getElementById("searchButton");
const searchTypeButtons = document.querySelectorAll(".search-type-btn");
const searchItems = document.querySelectorAll(".search-result-item");
const searchNoResults = document.querySelector(".search-no-results");

function applySearchFilters() {
    if (!searchItems.length) return;

    const raw = searchInput ? searchInput.value : "";
    const maxLen = typeof App !== "undefined" && App.LIMITS ? App.LIMITS.searchQuery : FALLBACK_SEARCH_QUERY_MAX_LENGTH;
    const query = (typeof raw === "string" ? raw.trim().slice(0, maxLen) : "").toLowerCase();
    const activeTypeBtn = document.querySelector(".search-type-btn.active");
    const typeFilter = activeTypeBtn ? (activeTypeBtn.dataset.filter || "all").toLowerCase() : "all";

    let visibleCount = 0;
    searchItems.forEach((item) => {
        const type = (item.dataset.type || "").toLowerCase();
        const text = item.textContent.toLowerCase();
        const matchesType = typeFilter === "all" || type === typeFilter;
        const matchesQuery = !query || text.includes(query);
        const show = matchesType && matchesQuery;
        item.classList.toggle("search-hidden", !show);
        if (show) visibleCount++;
    });

    if (searchNoResults) {
        searchNoResults.style.display = visibleCount === 0 ? "block" : "none";
    }
}

if (searchInput && searchItems.length) {
    searchTypeButtons.forEach((btn) => {
        btn.addEventListener("click", () => {
            searchTypeButtons.forEach((b) => b.classList.toggle("active", b === btn));
            applySearchFilters();
        });
    });
    if (searchButton) searchButton.addEventListener("click", applySearchFilters);
    searchInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
            e.preventDefault();
            applySearchFilters();
        }
    });
    applySearchFilters();
}

// ========== 11. CONTACT FORM ==========
const contactForm = document.querySelector(".contact-form");
if (contactForm) {
    contactForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        if (typeof App === "undefined") {
            const msg = document.createElement("p");
            msg.className = "form-note";
            msg.style.marginTop = "0.75rem";
            msg.style.color = "#a5b4fc";
            msg.textContent = "This is a demo form. Load app.js and set the form data-api to your API URL to enable submissions.";
            contactForm.querySelector('button[type="submit"]')?.after(msg);
            return;
        }

        const apiUrl = (contactForm.getAttribute("data-api") || contactForm.getAttribute("action") || "").trim();
        const useApi = apiUrl && apiUrl !== "#" && (apiUrl.startsWith("http") || apiUrl.startsWith("/"));

        if (useApi) {
            await App.submitContactForm(contactForm, apiUrl);
            return;
        }

        App.removeFormFeedback(contactForm);
        const lang = App.getStoredLang();
        const messages = {
            en: "This is a demo form. Set data-api=\"http://localhost:3000/api/contact\" on the form and run the server to submit.",
            bn: "এটি একটি ডেমো ফর্ম। সাবমিশন চালু করতে ফর্মে data-api সেট করুন এবং সার্ভার চালু করুন।",
        };
        App.showFormFeedback(contactForm, "error", messages[lang] || messages.en);
    });
}

// ========== 12. AUTH FORMS (DEMO — PREVENT SUBMIT) ==========
document.querySelectorAll(".auth-form").forEach((form) => {
    form.addEventListener("submit", (e) => {
        e.preventDefault();
        const msg = form.querySelector(".auth-note") || document.createElement("p");
        if (!msg.classList.contains("auth-note")) msg.className = "auth-note";
        msg.textContent = "This is a demo. Connect to a real auth backend to enable login or sign up.";
        msg.style.marginTop = "0.75rem";
        msg.style.color = "#9ca3af";
        form.querySelector('button[type="submit"]')?.after(msg);
    });
});
