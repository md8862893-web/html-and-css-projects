# Production Refactoring — Summary of Changes

This document describes the **structural and quality** refactor applied to the Chayapoth Studio project. **Functionality is unchanged**: no feature additions or removals, no URL or navigation changes.

---

## 1. Folder organization

| Change | Reason |
|--------|--------|
| **`docs/`** | All secondary documentation (analysis, refactoring notes) lives in one place. Root keeps only README and project files. |
| **`docs/analysis-and-improvements.md`** | Previous `ANALYSIS_AND_IMPROVEMENTS.md` moved here; filename uses kebab-case for consistency. |
| **HTML and assets stay at root** | Moving pages into `public/` would require updating every internal link and path. Kept current layout to avoid breakage; structure is documented instead. |

**Server** already followed a clear layout (`config`, `controllers`, `middleware`, `routes`, `validators`). Only file **naming** was updated (see below).

---

## 2. Naming conventions

| Before | After | Reason |
|--------|--------|--------|
| `script.js` | `main.js` | Clearly indicates the main entry script; avoids generic "script". |
| `contactRoutes.js` | `contact.routes.js` | Dot convention groups by feature (contact.*) and layer (.routes). |
| `contactController.js` | `contact.controller.js` | Same pattern; improves scanability in the file list. |
| `contactValidator.js` | `contact.validator.js` | Same pattern. |
| `notFound.js` | `notFound.middleware.js` | Optional: makes middleware role explicit. Kept as `notFound.js` for brevity; middleware folder already implies role. |

**Constants**: Existing `UPPER_SNAKE` for true constants (e.g. `LANG_KEY`, `LIMITS`) retained in both client and server.

---

## 3. Code structure

### Client (`assets/js/`)

- **`main.js`**: File header with a short table-of-contents and list of DOM IDs/selectors used. Top-of-file constants for magic strings (e.g. language key, default search limit). Logic unchanged; only organization and comments.
- **`app.js`**: JSDoc added for the public API (`getStoredLang`, `setStoredLang`, `validateContactForm`, `showFormFeedback`, `submitContactForm`, etc.) so the module contract is explicit. No behavior change.

### Server (`server/src/`)

- **Config**: Rate-limit window and max requests, and API path prefix, moved into `config`. Single source of truth for tunable values; no logic change.
- **Error handler**: Invalid JSON (body parser) error handled explicitly in the central error middleware; response shape unchanged.
- **Requires**: All `require()` paths updated to the new filenames (`contact.routes.js`, etc.).

---

## 4. Security (no functional change)

- **CORS**: Already restricted to a single origin via `CORS_ORIGIN`. Documented in config that it must be a single origin in production.
- **Rate limiting**: Values (window, max) moved to config so they can be tuned without editing middleware code.
- **Logging**: Confirmed that request body is not logged in production (only non-PII summary in dev). No code change; noted in comments.

---

## 5. Performance and maintainability

- **Script load order**: All pages that need the contact form load `app.js` before `main.js`; order is documented in README and in `docs/refactoring.md`.
- **CSS**: No structural change; design tokens and organization already in place. No new files or splits to avoid cache and path churn.
- **Single responsibility**: Existing filter helpers (`initCategoryFilter`, `initRoleFilter`) and form handling are already separated; refactor only renames and documents.

---

## 6. What was not changed

- **All HTML** — No edits to markup, links, or structure (except script `src` from `script.js` to `main.js`).
- **All URLs and navigation** — Same links, same pages, same behavior.
- **CSS file name and structure** — `styles.css` and single-file layout kept to avoid updating every HTML reference and to avoid cache invalidation.
- **API contract** — Request/response shapes for `POST /api/contact` unchanged.
- **Feature set** — No new features, no removed features.

---

## 7. File change checklist

- [x] `docs/refactoring.md` created
- [x] `ANALYSIS_AND_IMPROVEMENTS.md` → `docs/analysis-and-improvements.md`
- [x] README link to analysis doc updated
- [x] Server: `contactRoutes.js` → `contact.routes.js`, controller and validator similarly renamed; `index.js` and route file requires updated
- [x] Server: config extended with rate limit and API prefix; index uses them
- [x] `assets/js/script.js` → `assets/js/main.js`; all HTML script references updated to `main.js`
- [x] `main.js`: file header and top-level constants added
- [x] `app.js`: JSDoc for public API added
