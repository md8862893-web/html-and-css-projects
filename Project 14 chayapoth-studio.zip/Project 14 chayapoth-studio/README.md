# Chayapoth Studio

A static, multi-page website for **Chayapoth Studio** — a digital studio from Bangladesh building glassmorphic web, apps, ROMs and creative videos. The site supports English and Bangla (বাংলা) via a client-side language toggle.

## Project structure

```
chayapoth-studio/
├── index.html          # Home
├── about.html          # About the studio
├── services.html       # Services
├── projects.html       # Projects + filter
├── portfolio.html      # Team/portfolio + filter
├── blog.html           # Blog list + filter
├── blog-post.html      # Single blog post
├── news.html           # News + filter
├── downloads.html      # Downloads + filter
├── videos.html         # Videos + filter
├── ai.html             # AI assistant
├── support.html        # Help & FAQ
├── contact.html        # Contact form
├── login.html          # Login / sign up (static)
├── search.html         # Search
├── assets/
│   ├── css/
│   │   └── styles.css  # All styles (base, components, page-specific)
│   └── js/
│       ├── app.js     # Validation, form submit, i18n helpers
│       └── main.js    # Nav, language, filters, search, contact, auth
├── docs/
│   ├── analysis-and-improvements.md  # Codebase analysis and improvements
│   └── refactoring.md                # Production refactor summary
└── README.md           # This file
```

## How to run

- **Local:** Open `index.html` in a browser, or run a local server (e.g. `npx serve .` or `python -m http.server`) to avoid `file://` limitations.
- **Deploy:** Upload the folder to any static host (Netlify, Vercel, GitHub Pages, etc.). No build step required.

## Frontend standards (refactor)

- **Design tokens:** `styles.css` uses CSS custom properties (`:root`) for colors, spacing, radii, and transitions so themes and layout can be updated in one place.
- **Responsive:** Breakpoints at 480px (safe area, touch targets), 640px, 768px, 992px; optional `prefers-reduced-motion` for accessibility.
- **Accessibility:** Skip link (“Skip to main content”), `aria-label` on nav, `:focus-visible` on buttons and links, `main#main-content` for skip target. Apply the same pattern to other pages (skip link + `id="main-content"` on `<main>`).
- **Layout:** `.page-wrapper > main` uses `flex: 1 0 auto` so the footer stays at the bottom on short viewports.

## Production-ready head (recommended for all pages)

Copy the following into each page’s `<head>` for better SEO and performance. Replace the description and title per page.

```html
<meta name="description" content="Chayapoth Studio — [Page-specific description]">
<title>Chayapoth Studio | [Page Name]</title>

<!-- Preconnect for faster font loading -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<!-- Google Fonts with display=swap -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Noto+Sans+Bengali:wght@300;400;500;600;700&display=swap" rel="stylesheet">
```

## Contact form and backend

**Static only:** The contact form has `action="#"` and `data-api=""`. Submissions are intercepted; client-side validation and a demo message are shown. Load `assets/js/app.js` before `assets/js/main.js` on the contact page (already set in `contact.html`).

**With backend:** A minimal Node.js API is in `server/` (MVC-style: routes → controllers → validators). It provides:

- **POST /api/contact** — validated, rate-limited, sanitized contact submission.
- **Security:** Helmet, CORS, rate limit (10 req/15 min), body size limit, no stack traces in production.
- **Validation:** Required fields, email format, allowlist for project type and budget.

To use it:

1. `cd server && npm install && cp .env.example .env` — set `CORS_ORIGIN` to your frontend origin (e.g. `http://localhost:5500`).
2. `npm run dev` to start the API on port 3000.
3. On the contact form, set `data-api="http://localhost:3000/api/contact"` (or your deployed API URL). Submissions will POST to the API; validation errors and success messages are shown below the button.

See `server/README.md` for API details and production notes.

## Documentation

- [docs/analysis-and-improvements.md](docs/analysis-and-improvements.md) — Past analysis and improvement log.
- [docs/refactoring.md](docs/refactoring.md) — Production refactor summary (naming, structure, no functionality change).

## Next steps (see [docs/analysis-and-improvements.md](docs/analysis-and-improvements.md))

- Use a static site generator or build step so header/footer are partials (one source of truth).
- Replace emoji icons (🔍, ☰) with SVG for accessibility.
- Split CSS into base, components, and page-specific files; add a minimal build if needed.
- Add favicon and optional PWA manifest.
- Connect the contact form to a real backend and add validation.

## License

All rights reserved — Chayapoth Studio.
